import{a as t}from"../chunks/entry.CW6nvldi.js";export{t as start};
