import{a as t}from"../chunks/entry.C5JP9_87.js";export{t as start};
