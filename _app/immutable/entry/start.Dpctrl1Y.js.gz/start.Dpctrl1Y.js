import{a as t}from"../chunks/entry.D6g5Ij9A.js";export{t as start};
