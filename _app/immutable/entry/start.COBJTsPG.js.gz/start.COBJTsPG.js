import{a as t}from"../chunks/entry.f4925dxl.js";export{t as start};
