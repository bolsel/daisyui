import{L as e,_ as n}from"../chunks/0.6x2o68ip.js";export{e as component,n as universal};
